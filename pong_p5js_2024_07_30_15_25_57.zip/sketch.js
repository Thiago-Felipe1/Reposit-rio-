function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);     
}

let yBolinha = 300;
let xBolinha = 200;
let diametro = 15;

let velocidadeYBolinha = 5;
let velocidadeXBolinha = 5;

function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);     
circle(xBolinha ,yBolinha ,diametro)

xBolinha += velocidadeXBolinha;
yBolinha += velocidadeYBolinha;

if (xBolinha > width || xBolinha < 0) {
  velocidadeXBolinha *= -1;
}
  if (yBolinha > height || yBolinha < 0) {
  velocidadeYBolinha *= -1;
}
}

  














